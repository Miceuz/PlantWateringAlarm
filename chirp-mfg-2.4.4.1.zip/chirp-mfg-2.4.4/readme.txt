Chirp plant watering alarm v2.4.4

Contact: Albertas Mickenas, albertas@technariumas.lt, +37062684638

Shipping address:

Albertas Mickenas, Technariumas
phone no: +37062684638
Aguonu 17
LT-03012 Vilnius
Lithuania

PCB specification: FR4, 1.6mm, 35um copper, Black soldermask, HASL lead free
