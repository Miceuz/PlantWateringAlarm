Chirp plant watering alarm v2.4.5

Contact: Albertas Mickenas, albertas@technariumas.lt, +37062684638

Shipping address:

Albertas Mickenas, Technariumas
phone no: +37062684638
Panerių 45
LT-03202 Vilnius
Lithuania

PCB specification: FR4, 1.6mm, 35um copper, Black soldermask, HASL lead free
